import 'package:flutter/material.dart';

class ComunidadScreen extends StatefulWidget {
  const ComunidadScreen({super.key});

  @override
  State<ComunidadScreen> createState() => _ComunidadScreenState();
}

class _ComunidadScreenState extends State<ComunidadScreen> {
  // Estado para simular distintas perspectivas (POV)
  String _rolActual = 'Usuario: Juan';
  final List<String> _rolesDisponibles = [
    'Usuario: Juan',
    'Usuario: María',
    'Administrador'
  ];

  // Lista simulada de base de datos compartida entre usuarios
  final List<Map<String, String>> _alertas = [
    {
      'id': '1',
      'autor': 'Juan',
      'titulo': 'Falso comprobante de transferencia',
      'categoria': 'WhatsApp / Comercio',
      'descripcion': 'Te muestran un comprobante falso en el celular pidiendo entregar la mercadería rápido. Siempre verificá la acreditación en tu app real.',
      'fecha': 'Hace 2 horas',
    },
    {
      'id': '2',
      'autor': 'María',
      'titulo': 'Llamada por turno de vacunación / ANSES',
      'categoria': 'Llamada telefónica',
      'descripcion': 'Te piden un código de 6 dígitos que te llega por SMS. ¡Nunca lo pases! Es para apoderarse de tu cuenta de WhatsApp.',
      'fecha': 'Ayer',
    },
  ];

  // Filtro básico de moderación
  String? _validarYFiltrarContenido(String titulo, String descripcion) {
    if (titulo.length < 5 || descripcion.length < 15) {
      return 'El reporte es demasiado corto. Explicá con un poco más de detalle.';
    }

    final palabrasProhibidas = ['test', 'prueba', 'asdf', 'hola', 'nada', 'jaja'];
    final textoCompleto = '$titulo $descripcion'.toLowerCase();

    for (var palabra in palabrasProhibidas) {
      if (textoCompleto == palabra || textoCompleto.contains(' $palabra ')) {
        return 'El contenido no parece ser un reporte válido de estafa. Por favor redactá información útil.';
      }
    }

    return null; // Pasó el filtro de calidad
  }

  void _mostrarDialogoReportar() {
    final tituloController = TextEditingController();
    final descripcionController = TextEditingController();
    String? errorModeracion;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: Text(
                'Nueva alerta como: $_rolActual',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (errorModeracion != null) ...[
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.red[50],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.red[300]!),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                errorModeracion!,
                                style: const TextStyle(color: Colors.red, fontSize: 14),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: tituloController,
                      style: const TextStyle(fontSize: 18),
                      decoration: const InputDecoration(
                        labelText: 'Título del engaño',
                        hintText: 'Ej: Falso soporte técnico de WhatsApp',
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: descripcionController,
                      maxLines: 3,
                      style: const TextStyle(fontSize: 18),
                      decoration: const InputDecoration(
                        labelText: '¿Cómo ocurrió o qué piden?',
                        hintText: 'Ej: Llaman pidiendo un código de 6 dígitos para robar la cuenta...',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancelar', style: TextStyle(fontSize: 18)),
                ),
                ElevatedButton(
                  onPressed: () {
                    final titulo = tituloController.text.trim();
                    final descripcion = descripcionController.text.trim();

                    // Aplicar el filtro de moderación
                    final resultadoFiltro = _validarYFiltrarContenido(titulo, descripcion);

                    if (resultadoFiltro != null) {
                      setDialogState(() {
                        errorModeracion = resultadoFiltro;
                      });
                      return;
                    }

                    // Extraer nombre del usuario según el rol
                    final nombreAutor = _rolActual.replaceAll('Usuario: ', '');

                    setState(() {
                      _alertas.insert(0, {
                        'id': DateTime.now().millisecondsSinceEpoch.toString(),
                        'autor': nombreAutor,
                        'titulo': titulo,
                        'categoria': 'Reporte Comunitario',
                        'descripcion': descripcion,
                        'fecha': 'Justo ahora',
                      });
                    });

                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('¡Alerta validada y publicada con éxito!')),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[700],
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Publicar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _eliminarAlerta(String id) {
    setState(() {
      _alertas.removeWhere((alerta) => alerta['id'] == id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Alerta eliminada por el Administrador.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final esAdmin = _rolActual == 'Administrador';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Comunidad'),
        centerTitle: false,
        actions: [
          // Selector de POV / Rol en la barra superior
          Padding(
            padding: const EdgeInsets.only(right: 12.0),
            child: DropdownButton<String>(
              value: _rolActual,
              underline: const SizedBox(),
              icon: const Icon(Icons.account_circle, size: 28),
              onChanged: (nuevoRol) {
                if (nuevoRol != null) {
                  setState(() {
                    _rolActual = nuevoRol;
                  });
                }
              },
              items: _rolesDisponibles.map((rol) {
                return DropdownMenuItem(
                  value: rol,
                  child: Text(
                    rol,
                    style: TextStyle(
                      fontWeight: rol == 'Administrador' ? FontWeight.bold : FontWeight.normal,
                      color: rol == 'Administrador' ? Colors.red[800] : Colors.black,
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _mostrarDialogoReportar,
        icon: const Icon(Icons.add_alert, size: 28),
        label: Text('Reportar ($rolNombreLimpio)', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.red[700],
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: ListView.builder(
            padding: const EdgeInsets.all(24.0),
            itemCount: _alertas.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 20.0),
                  child: Card(
                    color: esAdmin ? Colors.red[50] : Colors.blue[50],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                        color: esAdmin ? Colors.red[300]! : Colors.blue[300]!,
                        width: 2,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Icon(
                            esAdmin ? Icons.admin_panel_settings : Icons.info_outline,
                            color: esAdmin ? Colors.red[800] : Colors.blue,
                            size: 32,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              esAdmin
                                  ? ' MODO ADMINISTRADOR ACTIVO: Tenés permisos para moderar y eliminar cualquier publicación inapropiada.'
                                  : ' Cambiá de usuario o entrá como Administrador desde el menú superior derecho para probar la moderación.',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: esAdmin ? FontWeight.bold : FontWeight.normal,
                                color: esAdmin ? Colors.red[900] : Colors.black87,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }

              final alerta = _alertas[index - 1];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.only(bottom: 16.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.orange[100],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  alerta['categoria']!,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orange[900],
                                    fontSize: 13,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                'por ${alerta['autor']}',
                                style: const TextStyle(fontWeight: FontWeight.w600, color: Colors.grey),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                                alerta['fecha']!,
                                style: TextStyle(color: Colors.grey[700], fontSize: 13),
                              ),
                              // Botón de eliminar disponible SOLO para el Administrador
                              if (esAdmin) ...[
                                const SizedBox(width: 8),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                                  tooltip: 'Eliminar reporte (Admin)',
                                  onPressed: () => _eliminarAlerta(alerta['id']!),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        alerta['titulo']!,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        alerta['descripcion']!,
                        style: const TextStyle(fontSize: 16, height: 1.3),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  String get rolNombreLimpio => _rolActual.replaceAll('Usuario: ', '');
}