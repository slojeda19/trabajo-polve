import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';

class AnalizadorScreen extends StatefulWidget {
  const AnalizadorScreen({super.key});

  @override
  State<AnalizadorScreen> createState() => _AnalizadorScreenState();
}

class _AnalizadorScreenState extends State<AnalizadorScreen> {
  final TextEditingController _inputController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _resultado;

  // PEGA ACÁ TU API KEY DE GOOGLE AI STUDIO
  final String _apiKey =
      'AQ.Ab8RN6KXsNlsSZG6pXBo5lx3bXtRDooW_T5wV82Gjj1kxMvGKA';

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

Future<void> _analizarTextoConIA() async {
    final textoOriginal = _inputController.text.trim();
    if (textoOriginal.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Por favor, ingresá un texto o enlace.')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _resultado = null;
    });

    try {
      if (_apiKey.isEmpty || _apiKey == 'TU_API_KEY_AQUI') {
        throw Exception('API Key no configurada');
      }

      final prompt = '''
Eres un experto en ciberseguridad enfocado en proteger a adultos mayores y estudiantes.
Analiza el siguiente texto/mensaje/enlace e identifica si es un intento de estafa, phishing o smishing.

Texto a analizar:
"$textoOriginal"

Responde EXCLUSIVAMENTE en el siguiente formato, sin agregar texto previo ni posterior:

RIESGO: [Escribe exactamente uno de estos tres valores: ALTO RIESGO, RIESGO MEDIO o SIN RIESGO DETECTADO]
MOTIVOS:
- [Primer motivo explicativo corto y claro]
- [Segundo motivo explicativo corto y claro]
CONSEJO: [Un consejo directo sobre qué hacer ahora]
''';

      final content = [Content.text(prompt)];
      final model = GenerativeModel(model: 'gemini-1.5-flash', apiKey: _apiKey);
      
      final response = await model.generateContent(content).timeout(
        const Duration(seconds: 8),
      );

      if (response.text != null && response.text!.isNotEmpty) {
        _procesarRespuestaIA(response.text!);
      } else {
        throw Exception('Respuesta vacía');
      }

    } catch (e) {
      // FALLBACK AUTOMÁTICO: Si Gemini falla o está saturado, genera la simulación local
      final respuestaSimulada = _generarRespuestaSimulada(textoOriginal);
      _procesarRespuestaIA(respuestaSimulada);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Servidor ocupado: Análisis generado en Modo Demo/Respaldo.'),
            backgroundColor: Colors.orange,
            duration: Duration(seconds: 3),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Algoritmo simple de simulación local
String _generarRespuestaSimulada(String texto) {
    final t = texto.toLowerCase();

    // Indicadores de contexto
    final tieneUrgencia = t.contains('urgente') || t.contains('ya') || t.contains('ahora') || t.contains('inmediato');
    final tieneSolicitudDinero = t.contains('plata') || t.contains('dinero') || t.contains('cbu') || t.contains('transfer') || t.contains('pagar');
    final tieneAmenaza = t.contains('mato') || t.contains('secuestro') || t.contains('daño') || t.contains('bloque');
    final tienePhishing = t.contains('http') || t.contains('link') || t.contains('clave') || t.contains('token') || t.contains('banco');

    // Validación por combinación de factores
    final esExtorsion = tieneAmenaza && (tieneSolicitudDinero || tieneUrgencia);
    final esEstafaUrgente = tieneUrgencia && tieneSolicitudDinero;
    final esPhishingEvidente = tienePhishing;

    if (esExtorsion || esEstafaUrgente || esPhishingEvidente) {
      return '''
RIESGO: ALTO RIESGO
MOTIVOS:
- Combina exigencia de dinero o datos con urgencia, amenazas o enlaces.
- Presenta una estructura típica de estafa o suplantación de identidad.
CONSEJO: No respondas el mensaje, no compartas datos personales ni transfieras dinero.
''';
    } else {
      return '''
RIESGO: SIN RIESGO DETECTADO
MOTIVOS:
- No se identificó combinación de factores de riesgo ni lenguaje coercitivo.
CONSEJO: Mantené siempre precaución antes de compartir información sensible.
''';
    }
  }
  void _procesarRespuestaIA(String respuesta) {
    String riesgo = 'RIESGO MEDIO';
    Color colorHex = Colors.amber[800]!;
    IconData icono = Icons.warning_amber_rounded;
    List<String> motivos = [];
    String consejo = '';

    // Extraer riesgo
    if (respuesta.contains('RIESGO: ALTO RIESGO')) {
      riesgo = 'ALTO RIESGO';
      colorHex = Colors.red[700]!;
      icono = Icons.cancel_outlined;
    } else if (respuesta.contains('RIESGO: SIN RIESGO DETECTADO')) {
      riesgo = 'SIN RIESGO DETECTADO';
      colorHex = Colors.green[700]!;
      icono = Icons.check_circle_outline;
    } else if (respuesta.contains('RIESGO: RIESGO MEDIO')) {
      riesgo = 'RIESGO MEDIO';
      colorHex = Colors.amber[800]!;
      icono = Icons.warning_amber_rounded;
    }

    // Extraer motivos y consejo
    final lineas = respuesta.split('\n');
    bool enMotivos = false;

    for (var linea in lineas) {
      linea = linea.trim();
      if (linea.startsWith('MOTIVOS:')) {
        enMotivos = true;
        continue;
      }
      if (linea.startsWith('CONSEJO:')) {
        enMotivos = false;
        consejo = linea.replaceFirst('CONSEJO:', '').trim();
        continue;
      }

      if (enMotivos && linea.startsWith('-')) {
        motivos.add(linea.replaceFirst('-', '').trim());
      }
    }

    if (motivos.isEmpty) {
      motivos.add('El análisis inteligente no detectó anomalías evidentes.');
    }

    setState(() {
      _resultado = {
        'riesgo': riesgo,
        'color': colorHex,
        'icono': icono,
        'motivos': motivos,
        'consejo': consejo,
      };
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detector Anti-Estafas (IA)'),
        centerTitle: true,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Pegá acá el mensaje o enlace sospechoso:',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const SizedBox(height: 16.0),

                TextField(
                  controller: _inputController,
                  maxLines: 5,
                  style: const TextStyle(fontSize: 18.0),
                  decoration: InputDecoration(
                    hintText:
                        'Ejemplo: "Hola papá, cambié de número. Agendame y mandame una transferencia para pagar la luz..."',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                ),
                const SizedBox(height: 24.0),

                // BOTÓN DE ANÁLISIS
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _analizarTextoConIA,
                  icon: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3,
                          ),
                        )
                      : const Icon(Icons.psychology, size: 28),
                  label: Text(
                    _isLoading ? 'ANALIZANDO CON IA...' : 'ANALIZAR CON IA',
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[700],
                    foregroundColor: Colors.white,
                    minimumSize: const Size(double.infinity, 55),
                  ),
                ),
                const SizedBox(height: 24.0),

                // TARJETA DE RESULTADO GENERADA POR LA IA
                if (_resultado != null) ...[
                  Card(
                    color: _resultado!['color'].withOpacity(0.1),
                    shape: RoundedRectangleBorder(
                      side: BorderSide(color: _resultado!['color'], width: 3),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                _resultado!['icono'],
                                color: _resultado!['color'],
                                size: 36,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _resultado!['riesgo'],
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    color: _resultado!['color'],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          const Text(
                            'Análisis de la IA:',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 8),
                          ...(_resultado!['motivos'] as List<String>).map(
                            (motivo) => Padding(
                              padding: const EdgeInsets.only(bottom: 6.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    '• ',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 18,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      motivo,
                                      style: const TextStyle(fontSize: 16),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          if ((_resultado!['consejo'] as String)
                              .isNotEmpty) ...[
                            const SizedBox(height: 12),
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: _resultado!['color']),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.lightbulb,
                                    color: _resultado!['color'],
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      _resultado!['consejo'],
                                      style: const TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24.0),
                ],

                const Divider(thickness: 2),
                const SizedBox(height: 16.0),

                // SECCIONES ADICIONALES
                const Text(
                  'Otras secciones:',
                  style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16.0),

                OutlinedButton.icon(
                  onPressed: () => Navigator.pushNamed(context, '/comunidad'),
                  icon: const Icon(Icons.people, size: 28),
                  label: const Text('Ver Alertas Comunitarias'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 55),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(height: 12.0),

                OutlinedButton.icon(
                  onPressed: () => Navigator.pushNamed(context, '/academia'),
                  icon: const Icon(Icons.school, size: 28),
                  label: const Text('Academia Anti-Estafas'),
                  style: OutlinedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 55),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
