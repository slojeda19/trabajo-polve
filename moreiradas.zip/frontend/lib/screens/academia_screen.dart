import 'package:flutter/material.dart';

class AcademiaScreen extends StatefulWidget {
  const AcademiaScreen({super.key});

  @override
  State<AcademiaScreen> createState() => _AcademiaScreenState();
}

class _AcademiaScreenState extends State<AcademiaScreen> {
  int _preguntaActual = 0;
  int _puntaje = 0;
  int? _opcionSeleccionada;
  bool _respondido = false;
  bool _mostrarResultadoQuiz = false;

  final List<Map<String, dynamic>> _preguntas = [
    {
      'pregunta': '1. Una persona de tu banco te llama para decirte que robaron tu cuenta y exige tu Clave Token. ¿Qué hacés?',
      'opciones': [
        'Corto la llamada; el banco NUNCA pide claves o tokens.',
        'Se la entrego rápido para asegurar mi dinero.',
        'Le pido que me vuelva a llamar en 10 minutos.'
      ],
      'correcta': 0,
      'explicacion': 'Ninguna entidad bancaria ni organismo oficial te pedirá tu contraseña, PIN o clave Token por ningún medio.'
    },
    {
      'pregunta': '2. Un conocido te habla por WhatsApp pidiéndote prestada plata con urgencia. ¿Qué conviene hacer?',
      'opciones': [
        'Transferirle de inmediato para ayudarlo.',
        'Llamarlo por teléfono o pedirle una nota de voz para verificar.',
        'Ignorar el mensaje y bloquearlo sin preguntar.'
      ],
      'correcta': 1,
      'explicacion': 'Suelen clonar o hackear cuentas de WhatsApp. Siempre confirmá la identidad por llamada tradicional o voz antes de enviar dinero.'
    },
    {
      'pregunta': '3. Te llega un SMS con un código de 6 dígitos de WhatsApp y alguien te pide que se lo reenvíes. ¿Qué hacés?',
      'opciones': [
        'Se lo reenvío si me dice que se equivocó.',
        'Lo publico en redes sociales para consultar.',
        'Jamás lo comparto; es el código para apoderarse de mi cuenta.'
      ],
      'correcta': 2,
      'explicacion': 'Ese código de 6 dígitos es el acceso exclusivo a tu WhatsApp. Si lo das, te robarán la cuenta.'
    },
    {
      'pregunta': '4. Un supuesto soporte técnico te pide instalar una app como "AnyDesk" o "TeamViewer" en tu celular. ¿Qué hacés?',
      'opciones': [
        'La instalo para que me ayuden.',
        'Rechazo instalarla; esas apps les dan control total de mi pantalla y bancos.',
        'Se la recomiendo a mis amigos.'
      ],
      'correcta': 1,
      'explicacion': 'Las aplicaciones de control remoto permiten a los delincuentes ver tu pantalla y vaciar tus billeteras o bancos.'
    },
    {
      'pregunta': '5. Encontrás una oferta increíble en redes pero el vendedor exige transferencia por adelantado. ¿Qué hacés?',
      'opciones': [
        'Desconfío y exijo pagar mediante métodos seguros con protección al comprador.',
        'Transfiero antes de que se agote la oferta.',
        'Le envío una foto de mi tarjeta de débito.'
      ],
      'correcta': 0,
      'explicacion': 'Los precios insólitamente bajos combinados con exigencia de pago por adelantado son la estafa más común en redes.'
    },
    {
      'pregunta': '6. Recibís un email de "Netflix" o "Spotify" pidiéndote actualizar tu tarjeta en un enlace. ¿Qué hacés?',
      'opciones': [
        'Hago clic en el enlace del mail e ingreso los datos.',
        'Respondo al correo adjuntando mis datos.',
        'No toco el enlace; abro directamente la app oficial para verificar.'
      ],
      'correcta': 2,
      'explicacion': 'Es Phishing. Los correos falsos imitan el diseño de empresas conocidas para robar datos. Entrá siempre desde la app oficial.'
    },
    {
      'pregunta': '7. Te llaman diciendo que un familiar tuvo un accidente/secuestro y piden dinero urgente. ¿Qué hacés?',
      'opciones': [
        'Entro en pánico y preparo el dinero.',
        'Mantengo la calma, corto y llamo directamente a ese familiar para verificar.',
        'Le doy la dirección de mi casa al llamante.'
      ],
      'correcta': 1,
      'explicacion': 'Es el clásico secuestro virtual o "cuento del tío". Intentan generar pánico para evitar que pienses. Cortá y llamá a tu familiar.'
    },
    {
      'pregunta': '8. Te ofrecen un trabajo por WhatsApp donde pagan miles de pesos por dar "Likes", pero piden depositar dinero inicial. ¿Qué es?',
      'opciones': [
        'Una estafa donde perderás todo el dinero depositado.',
        'Una gran oportunidad laboral remota.',
        'Un bono de incentivo laboral.'
      ],
      'correcta': 0,
      'explicacion': 'Ningún trabajo real ni legítimo te pedirá depositar o pagar dinero para empezar a trabajar o cobrar tus ganancias.'
    },
    {
      'pregunta': '9. Al escanear un código QR en un bar o la calle, te redirige a una página pidiendo tu clave bancaria. ¿Qué hacés?',
      'opciones': [
        'Ingreso mis claves normalmente.',
        'Reinicio el celular.',
        'Cierro la página de inmediato; un QR de menú o cartel jamás debe pedir claves.'
      ],
      'correcta': 2,
      'explicacion': 'Se llama "QRLacking". Pegan adhesivos falsos sobre códigos reales para dirigir a las víctimas a sitios tramposos.'
    },
    {
      'pregunta': '10. Te avisan que ganaste un auto o premio, pero debés pagar un "gasto administrativo" para retirarlo. ¿Qué hacés?',
      'opciones': [
        'Pago el costo mínimo para recibir el premio grande.',
        'No pago nada; si tenés que pagar para recibir un premio, es una estafa.',
        'Pido un préstamo para cubrir el gasto.'
      ],
      'correcta': 1,
      'explicacion': 'Los premios falsos siempre exigen un depósito previo bajo la excusa de impuestos o fletes. Si te piden pagar, no hay premio.'
    }
  ];

  void _seleccionarOpcion(int indice) {
    if (_respondido) return;

    setState(() {
      _opcionSeleccionada = indice;
      _respondido = true;
      if (indice == _preguntas[_preguntaActual]['correcta']) {
        _puntaje += 10;
      }
    });
  }

  void _siguientePregunta() {
    if (_preguntaActual + 1 < _preguntas.length) {
      setState(() {
        _preguntaActual++;
        _opcionSeleccionada = null;
        _respondido = false;
      });
    } else {
      setState(() {
        _mostrarResultadoQuiz = true;
      });
    }
  }

  void _reiniciarQuiz() {
    setState(() {
      _preguntaActual = 0;
      _puntaje = 0;
      _opcionSeleccionada = null;
      _respondido = false;
      _mostrarResultadoQuiz = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Academia Anti-Estafas',
            style: TextStyle(
              fontSize: 24, 
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.none,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Aprendé a detectar fraudes comunes y poné a prueba tus conocimientos.',
            style: TextStyle(color: Colors.grey, decoration: TextDecoration.none),
          ),
          const SizedBox(height: 20),

          // Sección de Guías
          const Text(
            'Guías Rápidas',
            style: TextStyle(
              fontSize: 18, 
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.none,
            ),
          ),
          const SizedBox(height: 10),
          _buildModuloCard(
            title: '1. Suplantación de WhatsApp',
            description: 'Nunca entregues el código de 6 dígitos que te llega por SMS.',
            icon: Icons.chat_bubble_outline,
            color: Colors.green,
          ),
          _buildModuloCard(
            title: '2. Falsos Soporte Técnico',
            description: 'No instales aplicaciones de control remoto (como AnyDesk).',
            icon: Icons.phonelink_setup,
            color: Colors.blue,
          ),
          _buildModuloCard(
            title: '3. Compras Sospechosas',
            description: 'Si la oferta en redes es demasiado buena, probablemente sea estafa.',
            icon: Icons.shopping_bag_outlined,
            color: Colors.purple,
          ),

          const SizedBox(height: 30),

          // Cuestionario Interactivo
          const Text(
            'Desafío Anti-Estafas (10 Preguntas)',
            style: TextStyle(
              fontSize: 18, 
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.none,
            ),
          ),
          const SizedBox(height: 10),
          _buildTriviaCard(),
        ],
      ),
    );
  }

  Widget _buildModuloCard({
    required String title,
    required String description,
    required IconData icon,
    required Color color,
  }) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.2),
          child: Icon(icon, color: color),
        ),
        title: Text(
          title, 
          style: const TextStyle(fontWeight: FontWeight.bold, decoration: TextDecoration.none)
        ),
        subtitle: Text(description, style: const TextStyle(decoration: TextDecoration.none)),
      ),
    );
  }

  Widget _buildTriviaCard() {
    final preguntaData = _preguntas[_preguntaActual];
    final int respuestaCorrecta = preguntaData['correcta'];

    return Card(
      color: Colors.blue.shade50,
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _mostrarResultadoQuiz
            ? Column(
                children: [
                  const Icon(Icons.stars, size: 60, color: Colors.amber),
                  const SizedBox(height: 10),
                  const Text(
                    '¡Trivia Completada!',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, decoration: TextDecoration.none),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Obtuviste $_puntaje de 100 puntos.',
                    style: const TextStyle(fontSize: 18, decoration: TextDecoration.none),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _reiniciarQuiz,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Volver a Intentar'),
                  )
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Pregunta ${_preguntaActual + 1} de ${_preguntas.length}',
                        style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, decoration: TextDecoration.none),
                      ),
                      Text(
                        'Puntaje: $_puntaje pts',
                        style: const TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, decoration: TextDecoration.none),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    preguntaData['pregunta'],
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, decoration: TextDecoration.none),
                  ),
                  const SizedBox(height: 16),

                  // Lista de opciones
                  ...List.generate(
                    (preguntaData['opciones'] as List).length,
                    (index) {
                      Color? buttonColor;
                      Color textColor = Colors.black87;

                      if (_respondido) {
                        if (index == respuestaCorrecta) {
                          buttonColor = Colors.green.shade600;
                          textColor = Colors.white;
                        } else if (index == _opcionSeleccionada) {
                          buttonColor = Colors.red.shade600;
                          textColor = Colors.white;
                        }
                      }

                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: buttonColor,
                            foregroundColor: textColor,
                            alignment: Alignment.centerLeft,
                            padding: const EdgeInsets.all(12),
                          ),
                          onPressed: () => _seleccionarOpcion(index),
                          child: Text(
                            preguntaData['opciones'][index],
                            style: TextStyle(color: textColor, decoration: TextDecoration.none),
                          ),
                        ),
                      );
                    },
                  ),

                  // Retroalimentación explicativa
                  if (_respondido) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _opcionSeleccionada == respuestaCorrecta
                            ? Colors.green.shade100
                            : Colors.red.shade100,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _opcionSeleccionada == respuestaCorrecta
                              ? Colors.green
                              : Colors.red,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                _opcionSeleccionada == respuestaCorrecta
                                    ? Icons.check_circle
                                    : Icons.cancel,
                                color: _opcionSeleccionada == respuestaCorrecta
                                    ? Colors.green.shade800
                                    : Colors.red.shade800,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _opcionSeleccionada == respuestaCorrecta
                                      ? '¡Respuesta Correcta!'
                                      : '¡Incorrecto! La opción correcta era la N° ${respuestaCorrecta + 1}.',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: _opcionSeleccionada == respuestaCorrecta
                                        ? Colors.green.shade900
                                        : Colors.red.shade900,
                                    decoration: TextDecoration.none,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            preguntaData['explicacion'],
                            style: const TextStyle(color: Colors.black87, decoration: TextDecoration.none),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue.shade700,
                          foregroundColor: Colors.white,
                        ),
                        onPressed: _siguientePregunta,
                        child: Text(
                          _preguntaActual + 1 == _preguntas.length
                              ? 'Ver Resultados Finales'
                              : 'Siguiente Pregunta',
                        ),
                      ),
                    ),
                  ],
                ],
              ),
      ),
    );
  }
}