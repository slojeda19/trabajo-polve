import 'package:flutter/material.dart';
import 'screens/analizador_screen.dart';
import 'screens/comunidad_screen.dart';
import 'screens/academia_screen.dart'; // Importación agregada

void main() {
  runApp(const AntiEstafasApp());
}

class AntiEstafasApp extends StatelessWidget {
  const AntiEstafasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Anti-Estafas',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const AnalizadorScreen(),
        '/comunidad': (context) => const ComunidadScreen(),
        '/academia': (context) => const AcademiaScreen(), // Ruta agregada
      },
    );
  }
}