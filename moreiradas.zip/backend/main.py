from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List

app = FastAPI(title="API Detector Anti-Estafas")

# Configuración de CORS obligatoria para Flutter Web
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnalisisRequest(BaseModel):
    texto: str

class AnalisisResponse(BaseModel):
    riesgo: str
    color: str
    motivos: List[str]
    palabras_clave: List[str]

@app.post("/analizar", response_model=AnalisisResponse)
def analizar_texto(req: AnalisisRequest):
    texto = req.texto.lower()
    motivos = []
    palabras_clave = []
    
    # Patrones de ingeniería social y urgencia
    palabras_urgencia = ["urgente", "bloqueo", "suspendida", "cbu", "inmediato", "clave", "token", "verificar"]
    extensiones_sospechosas = [".xyz", ".top", ".club", ".online", ".site", ".tk", ".ml"]
    
    # 1. Analizar palabras de urgencia
    for palabra in palabras_urgencia:
        if palabra in texto:
            palabras_clave.append(palabra)
            motivos.append(f'Contiene lenguaje de presión o urgencia: "{palabra}".')

    # 2. Analizar enlaces inseguros
    if "http://" in texto:
        motivos.append("Contiene un enlace no seguro (utiliza HTTP en lugar de HTTPS).")
    
    # 3. Analizar dominios sospechosos
    for ext in extensiones_sospechosas:
        if ext in texto:
            motivos.append(f'Utiliza una extensión de dominio sospechosa o no comercial ({ext}).')

    # Determinar el nivel de riesgo y color para el semáforo
    if len(motivos) >= 2 or any(ext in texto for ext in extensiones_sospechosas):
        riesgo = "ALTO RIESGO"
        color = "rojo"
    elif len(motivos) == 1:
        riesgo = "RIESGO MEDIO"
        color = "amarillo"
    else:
        riesgo = "SIN RIESGO DETECTADO"
        color = "verde"
        motivos.append("No se identificaron palabras sospechosas ni patrones evidentes de ingeniería social.")

    return AnalisisResponse(
        riesgo=riesgo,
        color=color,
        motivos=motivos,
        palabras_clave=palabras_clave
    )