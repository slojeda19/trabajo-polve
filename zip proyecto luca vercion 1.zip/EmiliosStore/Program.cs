namespace EmiliosStore
{
    internal static class Program
    {
        // Inicia la aplicación en la vista de acceso.
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Vistas.Vista01LoginForm());
        }
    }
}
