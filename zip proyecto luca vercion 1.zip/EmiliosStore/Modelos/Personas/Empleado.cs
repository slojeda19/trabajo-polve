﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Personas
{
    // Base de los empleados con acceso al sistema.
    internal class Empleado : Persona
    {
        private decimal _sueldo;
        private string _usuario;
        private string _contrasena;

        public Empleado(
            string nombre,
            string dni,
            string direccion,
            decimal sueldo,
            string usuario,
            string contrasena
        ) : base(nombre, dni, direccion)
        {
            _sueldo = sueldo;
            _usuario = usuario;
            _contrasena = contrasena;
        }

        public decimal Sueldo
        {
            get => _sueldo;
            set => _sueldo = value;
        }

        public string Usuario
        {
            get => _usuario;
            set => _usuario = value;
        }

        public string Contrasena
        {
            get => _contrasena;
            set => _contrasena = value;
        }

        public bool IniciarSesion(string usuario, string contrasena)
        {
            // Compara los datos ingresados con los del empleado.
            return _usuario == usuario && _contrasena == contrasena;
        }
    }
}
