﻿using EmiliosStore.Modelos.Catalogo;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Personas
{
    // Empleado autorizado para editar catálogo y reseñas.
    internal class Administrativo : Empleado
    {
        public Administrativo(
                   string nombre,
                   string dni,
                   string direccion,
                   decimal sueldo,
                   string usuario,
                   string contrasena
               ) : base(nombre, dni, direccion, sueldo, usuario, contrasena)
        {
        }

        public void CrearResena(Videojuego videojuego, string descripcion, int puntaje)
        {
            videojuego.Resena = new Reseña(videojuego, descripcion, puntaje);
        }

        public void RestarInventario(Videojuego videojuego)
        {
            // Evita que el stock sea negativo.
            if (videojuego.Stock > 0)
            {
                videojuego.Stock--;
            }
        }

        public void RenombrarVideojuego(Videojuego videojuego, string nuevoNombre)
        {
            videojuego.Nombre = nuevoNombre;
        }
    }
}

