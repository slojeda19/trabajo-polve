﻿using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Operaciones;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Personas
{
    // Empleado que registra ventas a clientes.
    internal class Vendedor : Empleado
    {
        private List<Venta> _ventasRealizadas;

        public Vendedor(
            string nombre,
            string dni,
            string direccion,
            decimal sueldo,
            string usuario,
            string contrasena
        ) : base(nombre, dni, direccion, sueldo, usuario, contrasena)
        {
            _ventasRealizadas = new List<Venta>();
        }

        public List<Venta> VentasRealizadas
        {
            get => _ventasRealizadas;
            set => _ventasRealizadas = value;
        }

        public Venta CrearVenta(Cliente cliente, List<Videojuego> videojuegos)
        {
            // Crea la compra y la vincula con cliente y vendedor.
            Compra compra = new Compra(cliente, videojuegos);
            Venta venta = new Venta(compra, this);

            _ventasRealizadas.Add(venta);
            cliente.AgregarCompra(compra);

            return venta;
        }

        public CompraConEnvio CrearVentaConEnvio(
            Cliente cliente,
            List<Videojuego> videojuegos,
            string direccionEnvio
        )
        {
            CompraConEnvio compra = new CompraConEnvio(
                cliente,
                videojuegos,
                direccionEnvio
            );

            cliente.AgregarCompra(compra);

            return compra;
        } 
    }
}
