﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Personas
{
    // Datos comunes de cualquier persona del sistema.
    internal class Persona
    {
        private string _nombre;
        private string _dni;
        private string _direccion;

        public Persona(string nombre, string dni, string direccion)
        {
            _nombre = nombre;
            _dni = dni;
            _direccion = direccion;
        }

        public string Nombre
        {
            get => _nombre;
            set
            {
                if (value != _nombre && value != "") _nombre = value;
            }
        }

        public string Dni
        {
            get => _dni;
            set
            {
                if (value != _dni && value != "") _dni = value;
            }
        }

        public string Direccion
        {
            get => _direccion;
            set
            {
                if (value != _direccion && value != "") _direccion = value;
            }
        }
    }
}

