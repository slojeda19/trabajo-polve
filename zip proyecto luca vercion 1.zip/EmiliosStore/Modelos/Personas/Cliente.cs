﻿using EmiliosStore.Modelos.Operaciones;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Personas
{
    // Cliente que puede iniciar sesión y registrar compras.
    internal class Cliente : Persona
    {
        private List<Compra> _comprasRealizadas;
        private List<Intercambio> _intercambiosRealizados;

        // Historial de solicitudes de intercambio realizadas por este cliente.
        public Cliente(string nombre, string dni, string direccion)
            : base(nombre, dni, direccion)
        {
            _comprasRealizadas = new List<Compra>();
            // new List crea una lista vacía y evita un error al intentar guardar el primer intercambio.
            _intercambiosRealizados = new List<Intercambio>();
        }

        public List<Compra> ComprasRealizadas
        {
            get => _comprasRealizadas;
            set => _comprasRealizadas = value;
        }

        public List<Intercambio> IntercambiosRealizados
        {
            get => _intercambiosRealizados;
            set => _intercambiosRealizados = value;
        }

        // "=>" devuelve directamente el resultado de comparar usuario y contraseña.
        //public bool IniciarSesion(string usuario, string contrasena) =>
        //    _usuario == usuario && _contrasena == contrasena;

        public void AgregarCompra(Compra compra)
        {
            // Guarda la compra en el historial del cliente.
            _comprasRealizadas.Add(compra);
        }

        // Guarda el intercambio para que el cliente pueda consultarlo luego.
        public void AgregarIntercambio(Intercambio intercambio)
        {
            // Add incorpora el pedido al historial de este cliente, no al de todos los clientes.
            _intercambiosRealizados.Add(intercambio);
        }
    }
}
