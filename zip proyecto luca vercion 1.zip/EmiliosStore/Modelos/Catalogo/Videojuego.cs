﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Catalogo
{
    // Representa un producto disponible en el catálogo.
    internal class Videojuego
    {
        private string _nombre;
        private Reseña? _resena;
        private Genero _genero;
        private decimal _precio;
        private int _stock;

        public Videojuego(
            string nombre,
            Genero genero,
            decimal precio,
            int stock
        )
        {
            _nombre = nombre;
            _genero = genero;
            _precio = precio;
            _stock = stock;
        }

        public string Nombre
        {
            get => _nombre;
            set
            {
                if (value != _nombre && value != "") _nombre = value;
            }
        }

        public Reseña? Resena
        {
            get => _resena;
            set => _resena = value;
        }

        public Genero Genero
        {
            get => _genero;
            set => _genero = value;
        }

        public decimal Precio
        {
            get => _precio;
            set => _precio = value;
        }

        public int Stock
        {
            get => _stock;
            set => _stock = value;
        }
    }
}
