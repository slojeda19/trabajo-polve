﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Catalogo
{
    // Guarda la opinión y puntaje de Emilio sobre un juego.
    internal class Reseña
    {
        private Videojuego _videojuego;
        private string _descripcion;
        private int _puntaje;

        public Reseña(Videojuego videojuego, string descripcion, int puntaje)
        {
            _videojuego = videojuego;
            _descripcion = descripcion;
            _puntaje = puntaje;
        }

        public Videojuego Videojuego
        {
            get => _videojuego;
            set => _videojuego = value;
        }

        public string Descripcion
        {
            get => _descripcion;
            set => _descripcion = value;
        }

        public int Puntaje
        {
            get => _puntaje;
            set => _puntaje = value;
        }
    }
}
