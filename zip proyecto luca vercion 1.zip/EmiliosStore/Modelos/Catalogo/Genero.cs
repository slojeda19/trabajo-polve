﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Catalogo
{
    // Agrupa videojuegos por categoría.
    internal class Genero
    {
        private string _nombre;
        private List<Videojuego> _videojuegos;

        public Genero(string nombre)
        {
            _nombre = nombre;
            _videojuegos = new List<Videojuego>();
        }

        public string Nombre
        {
            get => _nombre;
            set
            {
                if (value != _nombre && value != "") _nombre = value;
            }
        }

        public List<Videojuego> Videojuegos
        {
            get => _videojuegos;
            set => _videojuegos = value;
        }

        public void AgregarVideojuego(Videojuego videojuego)
        {
            // Mantiene la relación entre género y juego.
            _videojuegos.Add(videojuego);
        }
    }
}
