﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Catalogo
{
    internal class GeneroBueno
    {
        private string _nombre;
        private List<Videojuego> _videojuegos;

        public GeneroBueno(string nombre)
        {
            _nombre = nombre;
            _videojuegos = new List<Videojuego>();
        }

        public string Nombre { get => _nombre; set {

                if (value != _nombre && value != "")
                {
                    _nombre = value;
                }
            }
        }
        internal List<Videojuego> Videojuegos { get => _videojuegos; set => _videojuegos = value; }
    }
}
