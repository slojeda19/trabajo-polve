﻿using EmiliosStore.Modelos.Operaciones;
using EmiliosStore.Modelos.Personas;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Sucursales
{
    // Agrupa inventario, empleados, clientes y ventas del local.
    internal class Sucursal
    {
        private string _direccion;
        private Inventario _inventario;
        private List<Empleado> _empleados;
        private List<Cliente> _clientes;
        private List<Venta> _ventasRealizadas;

        public Sucursal(string direccion)
        {
            _direccion = direccion;
            _empleados = new List<Empleado>();
            _clientes = new List<Cliente>();
            _ventasRealizadas = new List<Venta>();

            // La sucursal crea y queda asociada a su inventario.
            _inventario = new Inventario();
            _inventario.Sucursal = this;
        }

        public string Direccion
        {
            get => _direccion;
            set
            {
                if (value != _direccion && value != "") _direccion = value;
            }
        }

        public Inventario Inventario
        {
            get => _inventario;
            set => _inventario = value;
        }

        public List<Empleado> Empleados
        {
            get => _empleados;
            set => _empleados = value;
        }

        public List<Cliente> Clientes
        {
            get => _clientes;
            set => _clientes = value;
        }

        public List<Venta> VentasRealizadas
        {
            get => _ventasRealizadas;
            set => _ventasRealizadas = value;
        }
    }
}

