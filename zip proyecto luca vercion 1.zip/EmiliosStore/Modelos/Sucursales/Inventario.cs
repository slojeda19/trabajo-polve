﻿using EmiliosStore.Modelos.Catalogo;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Sucursales
{
    // Contiene los juegos disponibles en una sucursal.
    internal class Inventario
    {
        private List<Videojuego> _videojuegos;
        private Sucursal? _sucursal;

        public Inventario()
        {
            _videojuegos = new List<Videojuego>();
        }

        public List<Videojuego> Videojuegos
        {
            get => _videojuegos;
            set => _videojuegos = value;
        }

        public Sucursal? Sucursal
        {
            get => _sucursal;
            set => _sucursal = value;
        }

        public bool VerificarStock(Videojuego videojuego)
        {
            // Informa si queda al menos una unidad.
            return videojuego.Stock > 0;
        }

        public void AgregarVideojuego(Videojuego videojuego)
        {
            _videojuegos.Add(videojuego);
        }
    }
}
