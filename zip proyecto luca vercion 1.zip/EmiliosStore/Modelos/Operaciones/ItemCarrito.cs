using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Sucursales;

namespace EmiliosStore.Modelos.Operaciones
{
    // Guarda el juego reservado y la sucursal de la que sale.
    internal class ItemCarrito
    {
        private Videojuego _juego;
        private Sucursal _sucursal;

        public ItemCarrito(Videojuego juego, Sucursal sucursal)
        {
            _juego = juego;
            _sucursal = sucursal;
        }

        public Videojuego Juego
        {
            get => _juego;
            set => _juego = value;
        }

        public Sucursal Sucursal
        {
            get => _sucursal;
            set => _sucursal = value;
        }
    }
}
