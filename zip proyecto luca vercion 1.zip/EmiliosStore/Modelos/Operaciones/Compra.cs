﻿using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Personas;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Operaciones
{
    // Compra realizada por un cliente.
    internal class Compra : Transaccion
    {
        private Cliente _cliente;
        private List<Videojuego> _articulos;

        public Compra(Cliente cliente, List<Videojuego> articulos)
        {
            _cliente = cliente;
            _articulos = articulos;

            // Calcula el total al crear la compra.
            CostoTotal = CalcularTotal();
        }

        public Cliente Cliente
        {
            get => _cliente;
            set => _cliente = value;
        }

        public List<Videojuego> Articulos
        {
            get => _articulos;
            set => _articulos = value;
        }

        public override decimal CalcularTotal()
        {
            return CalcularTotalDeVideojuegos(_articulos);
        }
    }
}
