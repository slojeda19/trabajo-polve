﻿using EmiliosStore.Modelos.Personas;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Operaciones
{
    // Operación que relaciona una compra con el vendedor.
    internal class Venta : Transaccion
    {
        private Compra _compra;
        private Vendedor _vendedor;

        public Venta(Compra compra, Vendedor vendedor)
        {
            _compra = compra;
            _vendedor = vendedor;
            CostoTotal = compra.CostoTotal;
        }

        public Compra Compra
        {
            get => _compra;
            set => _compra = value;
        }

        public Vendedor Vendedor
        {
            get => _vendedor;
            set => _vendedor = value;
        }

        public override decimal CalcularTotal()
        {
            return _compra.CostoTotal;
        }
    }
}
