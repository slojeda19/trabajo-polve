﻿using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Personas;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Operaciones
{
    // Compra que además guarda una dirección de entrega.
    internal class CompraConEnvio : Compra
    {
        private string _direccionEnvio;

        public CompraConEnvio(
            Cliente cliente,
            List<Videojuego> articulos,
            string direccionEnvio
        // base llama al constructor de Compra para reutilizar su cálculo de total.
        ) : base(cliente, articulos)
        {
            _direccionEnvio = direccionEnvio;
        }

        public string DireccionEnvio
        {
            get => _direccionEnvio;
            set => _direccionEnvio = value;
        }
    }
}
