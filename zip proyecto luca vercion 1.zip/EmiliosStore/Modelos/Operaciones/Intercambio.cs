using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Personas;
using EmiliosStore.Modelos.Sucursales;

namespace EmiliosStore.Modelos.Operaciones
{
    // Solicitud de canje enviada por un cliente.
    internal class Intercambio
    {
        private Cliente _cliente;
        private string _juegoOfrecido;
        private Videojuego _juegoSolicitado;
        private Sucursal _sucursalOrigen;
        private decimal _diferencia;
        private string _estado;
        private DateTime _fecha;

        // DateTime guarda fecha y hora para identificar cuándo se creó el pedido.
        public Intercambio(Cliente cliente, string juegoOfrecido, Videojuego juegoSolicitado, Sucursal sucursalOrigen, decimal diferencia)
        {
            _cliente = cliente;
            _juegoOfrecido = juegoOfrecido;
            _juegoSolicitado = juegoSolicitado;
            _sucursalOrigen = sucursalOrigen;
            _diferencia = diferencia;
            _estado = "Pendiente";
            // Now toma la fecha actual automáticamente y evita que el historial quede sin fecha.
            _fecha = DateTime.Now;
        }

        public Cliente Cliente { get => _cliente; set => _cliente = value; }
        public string JuegoOfrecido { get => _juegoOfrecido; set => _juegoOfrecido = value; }
        public Videojuego JuegoSolicitado { get => _juegoSolicitado; set => _juegoSolicitado = value; }
        public Sucursal SucursalOrigen { get => _sucursalOrigen; set => _sucursalOrigen = value; }
        public decimal Diferencia { get => _diferencia; set => _diferencia = value; }
        public string Estado { get => _estado; set => _estado = value; }
        public DateTime Fecha { get => _fecha; set => _fecha = value; }

        // ListBox usa ToString para mostrar un resumen del pedido.
        public override string ToString()
        {
            return $"{_cliente.Nombre}: ofrece {_juegoOfrecido} por {_juegoSolicitado.Nombre}";
        }
    }
}
