﻿using EmiliosStore.Modelos.Catalogo;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Operaciones
{
    // Base compartida de compras y ventas.
    internal class Transaccion
    {
        private DateTime _fecha;
        private decimal _costoTotal;
        private Factura? _factura;

        public Transaccion()
        {
            _fecha = DateTime.Now;
        }

        public DateTime Fecha
        {
            get => _fecha;
            set => _fecha = value;
        }

        public decimal CostoTotal
        {
            get => _costoTotal;
            set => _costoTotal = value;
        }

        public Factura? Factura
        {
            get => _factura;
            set => _factura = value;
        }

        // virtual permite que Compra y Venta cambien este cálculo si lo necesitan.
        public virtual decimal CalcularTotal()
        {
            return _costoTotal;
        }

        public decimal CalcularTotalDeVideojuegos(
            System.Collections.Generic.List<Videojuego> videojuegos
        )
        {
            // Suma el precio de cada juego recibido.
            decimal total = 0;

            foreach (Videojuego videojuego in videojuegos)
            {
                total = total + videojuego.Precio;
            }

            return total;
        }
    }
}
