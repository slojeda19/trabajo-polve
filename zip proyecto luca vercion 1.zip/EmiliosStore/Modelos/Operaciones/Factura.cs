﻿using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Personas;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmiliosStore.Modelos.Operaciones
{
    // Comprobante asociado a una compra realizada.
    internal class Factura
    {
        private Cliente _cliente;
        private Vendedor _vendedor;
        private List<Videojuego> _detalle;
        private int _numeroFactura;

        public Factura(
            Cliente cliente,
            Vendedor vendedor,
            List<Videojuego> detalle,
            int numeroFactura
        )
        {
            _cliente = cliente;
            _vendedor = vendedor;
            _detalle = detalle;
            _numeroFactura = numeroFactura;
        }

        public Cliente Cliente
        {
            get => _cliente;
            set => _cliente = value;
        }

        public Vendedor Vendedor
        {
            get => _vendedor;
            set => _vendedor = value;
        }

        public List<Videojuego> Detalle
        {
            get => _detalle;
            set => _detalle = value;
        }

        public int NumeroFactura
        {
            get => _numeroFactura;
            set => _numeroFactura = value;
        }
    }
}
