namespace EmiliosStore.Vistas
{
    // V05: solicitud de intercambio.
    public partial class Vista05IntercambioForm : Form
    {
        public Vista05IntercambioForm()
        {
            InitializeComponent();
        }
    }
}
