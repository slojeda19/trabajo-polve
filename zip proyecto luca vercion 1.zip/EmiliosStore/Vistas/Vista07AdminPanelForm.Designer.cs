namespace EmiliosStore.Vistas
{
    partial class Vista07AdminPanelForm
    {
        private void InitializeComponent()
        {
            lbl_tutulo = new Label();
            lbl_usuario = new Label();
            label3 = new Label();
            txt_Rol = new Label();
            Lbl_SucursalAsignada = new Label();
            Cbx_SucursalAsignada = new ComboBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            txt_textocambiableusuario = new Label();
            lbl_Rolactualcambiante = new Label();
            SuspendLayout();
            // 
            // lbl_tutulo
            // 
            lbl_tutulo.AutoSize = true;
            lbl_tutulo.Font = new Font("Segoe UI", 22F);
            lbl_tutulo.Location = new Point(202, 56);
            lbl_tutulo.Name = "lbl_tutulo";
            lbl_tutulo.Size = new Size(439, 60);
            lbl_tutulo.TabIndex = 0;
            lbl_tutulo.Text = "PANEL DE PERSONAL";
            // 
            // lbl_usuario
            // 
            lbl_usuario.AutoSize = true;
            lbl_usuario.Font = new Font("Segoe UI", 19F);
            lbl_usuario.Location = new Point(105, 149);
            lbl_usuario.Name = "lbl_usuario";
            lbl_usuario.Size = new Size(153, 51);
            lbl_usuario.TabIndex = 1;
            lbl_usuario.Text = "usuario:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19F);
            label3.Location = new Point(105, 222);
            label3.Name = "label3";
            label3.Size = new Size(0, 51);
            label3.TabIndex = 2;
            // 
            // txt_Rol
            // 
            txt_Rol.AutoSize = true;
            txt_Rol.Font = new Font("Segoe UI", 19F);
            txt_Rol.Location = new Point(105, 222);
            txt_Rol.Name = "txt_Rol";
            txt_Rol.Size = new Size(83, 51);
            txt_Rol.TabIndex = 3;
            txt_Rol.Text = "Rol:";
            // 
            // Lbl_SucursalAsignada
            // 
            Lbl_SucursalAsignada.AutoSize = true;
            Lbl_SucursalAsignada.Font = new Font("Segoe UI", 19F);
            Lbl_SucursalAsignada.Location = new Point(105, 296);
            Lbl_SucursalAsignada.Name = "Lbl_SucursalAsignada";
            Lbl_SucursalAsignada.Size = new Size(325, 51);
            Lbl_SucursalAsignada.TabIndex = 4;
            Lbl_SucursalAsignada.Text = "Sucursal Asignada";
            // 
            // Cbx_SucursalAsignada
            // 
            Cbx_SucursalAsignada.FormattingEnabled = true;
            Cbx_SucursalAsignada.Location = new Point(436, 314);
            Cbx_SucursalAsignada.Name = "Cbx_SucursalAsignada";
            Cbx_SucursalAsignada.Size = new Size(205, 33);
            Cbx_SucursalAsignada.TabIndex = 5;
            Cbx_SucursalAsignada.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F);
            button1.Location = new Point(105, 400);
            button1.Name = "button1";
            button1.Size = new Size(273, 41);
            button1.TabIndex = 6;
            button1.Text = "gestionar inventario";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 12F);
            button2.Location = new Point(410, 400);
            button2.Name = "button2";
            button2.Size = new Size(273, 41);
            button2.TabIndex = 7;
            button2.Text = "Revisar Intercambio";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 12F);
            button3.Location = new Point(105, 471);
            button3.Name = "button3";
            button3.Size = new Size(273, 41);
            button3.TabIndex = 8;
            button3.Text = "Editar reseñas";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 12F);
            button4.Location = new Point(410, 471);
            button4.Name = "button4";
            button4.Size = new Size(273, 41);
            button4.TabIndex = 9;
            button4.Text = "Administrar inventario";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Font = new Font("Segoe UI", 12F);
            button5.Location = new Point(105, 580);
            button5.Name = "button5";
            button5.Size = new Size(273, 41);
            button5.TabIndex = 10;
            button5.Text = "Cerrar Secion";
            button5.UseVisualStyleBackColor = true;
            // 
            // txt_textocambiableusuario
            // 
            txt_textocambiableusuario.AutoSize = true;
            txt_textocambiableusuario.Font = new Font("Segoe UI", 12F);
            txt_textocambiableusuario.Location = new Point(276, 164);
            txt_textocambiableusuario.Name = "txt_textocambiableusuario";
            txt_textocambiableusuario.Size = new Size(176, 32);
            txt_textocambiableusuario.TabIndex = 11;
            txt_textocambiableusuario.Text = "(usuario actual)";
            // 
            // lbl_Rolactualcambiante
            // 
            lbl_Rolactualcambiante.AutoSize = true;
            lbl_Rolactualcambiante.Font = new Font("Segoe UI", 12F);
            lbl_Rolactualcambiante.Location = new Point(276, 241);
            lbl_Rolactualcambiante.Name = "lbl_Rolactualcambiante";
            lbl_Rolactualcambiante.Size = new Size(131, 32);
            lbl_Rolactualcambiante.TabIndex = 12;
            lbl_Rolactualcambiante.Text = "(Rol actual)";
            lbl_Rolactualcambiante.Click += label7_Click;
            // 
            // Vista07AdminPanelForm
            // 
            ClientSize = new Size(799, 724);
            Controls.Add(lbl_Rolactualcambiante);
            Controls.Add(txt_textocambiableusuario);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(Cbx_SucursalAsignada);
            Controls.Add(Lbl_SucursalAsignada);
            Controls.Add(txt_Rol);
            Controls.Add(label3);
            Controls.Add(lbl_usuario);
            Controls.Add(lbl_tutulo);
            Name = "Vista07AdminPanelForm";
            Text = "V07 - Administración";
            ResumeLayout(false);
            PerformLayout();
        }

        private Label lbl_tutulo;
        private Label lbl_usuario;
        private Label label3;
        private Label txt_Rol;
        private Label Lbl_SucursalAsignada;
        private ComboBox Cbx_SucursalAsignada;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Label txt_textocambiableusuario;
        private Label lbl_Rolactualcambiante;
    }
}
