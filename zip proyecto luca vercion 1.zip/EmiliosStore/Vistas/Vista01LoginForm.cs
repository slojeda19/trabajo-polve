using EmiliosStore.Modelos.Personas;

namespace EmiliosStore.Vistas
{
    // V01: punto de entrada de la aplicación.
    public partial class Vista01LoginForm : Form
    {
        public Vista01LoginForm()
        {
            InitializeComponent();

            // Oculta los caracteres de la contraseña sin modificar el diseño.
            // Usa el nombre real del TextBox. Evita el error CS0103: nombre inexistente.
            txt_contraseña.UseSystemPasswordChar = true;

            // Agrega las opciones sin modificar el archivo visual creado con el diseñador.
            cbx_tipodeusuario.Items.AddRange(new object[] { "Cliente", "Vendedor", "Administrador" });
            // Deja Cliente elegido al abrir para evitar que el ComboBox quede vacío.
            cbx_tipodeusuario.SelectedIndex = 0;
            // Impide escribir un rol inexistente y evita comparaciones con texto inválido.
            cbx_tipodeusuario.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Text es el texto elegido en el ComboBox.
            string tipoUsuario = cbx_tipodeusuario.Text;

            //// Solo una cuenta de cliente puede acceder como Cliente.
            //if (tipoUsuario == "Cliente")
            //{
            //    foreach (Cliente cliente in AppData.Clientes)
            //    {
            //        // Lee los controles renombrados en el diseñador: usuario y contraseña.
            //        if (cliente.IniciarSesion(txt_usuario.Text.Trim(), txt_contraseña.Text))
            //        {
            //            AppData.ClienteActual = cliente;
            //            AppData.RolActual = "Cliente";
            //            new Vista02CatalogoForm().Show();
            //            return;
            //        }
            //    }

            //    MessageBox.Show("Usuario o contraseña de cliente incorrectos.");
            //    return;
            //}

            // Cuenta de prueba del vendedor. Después se reemplazará por empleados guardados.
            if (tipoUsuario == "Vendedor" && txt_usuario.Text.Trim() == "vendedor" && txt_contraseña.Text == "1234")
            {
                AppData.ClienteActual = null;
                AppData.RolActual = "Vendedor";
                new Vista07AdminPanelForm().Show();
                return;
            }

            // Cuenta de prueba del administrador, con permisos para todas las sucursales.
            if (tipoUsuario == "Administrador" && txt_usuario.Text.Trim() == "admin" && txt_contraseña.Text == "1234")
            {
                AppData.ClienteActual = null;
                AppData.RolActual = "Administrador";
                new Vista07AdminPanelForm().Show();
                return;
            }

            MessageBox.Show("El usuario, la contraseña o el tipo de usuario no son correctos.");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using Form1 registro = new Form1();
            registro.ShowDialog();
        }
    }
}
