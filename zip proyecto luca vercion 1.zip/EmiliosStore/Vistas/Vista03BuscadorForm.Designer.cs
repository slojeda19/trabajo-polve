namespace EmiliosStore.Vistas
{
    partial class Vista03BuscadorForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            // 
            // Vista03BuscadorForm
            // 
            ClientSize = new Size(1250, 689);
            Name = "Vista03BuscadorForm";
            Text = "V03 - Buscador";
            ResumeLayout(false);
        }
    }
}
