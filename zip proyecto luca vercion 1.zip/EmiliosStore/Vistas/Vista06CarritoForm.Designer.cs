namespace EmiliosStore.Vistas
{
    partial class Vista06CarritoForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista06CarritoForm";
            Text = "V06 - Carrito";
            ResumeLayout(false);
        }
    }
}
