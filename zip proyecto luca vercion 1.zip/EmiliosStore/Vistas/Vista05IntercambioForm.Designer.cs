namespace EmiliosStore.Vistas
{
    partial class Vista05IntercambioForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista05IntercambioForm";
            Text = "V05 - Intercambio";
            ResumeLayout(false);
        }
    }
}
