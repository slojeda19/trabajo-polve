namespace EmiliosStore.Vistas
{
    // V07: menú del personal.
    public partial class Vista07AdminPanelForm : Form
    {
        public Vista07AdminPanelForm()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
