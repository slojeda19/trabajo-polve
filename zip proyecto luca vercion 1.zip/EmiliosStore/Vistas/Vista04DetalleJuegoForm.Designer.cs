namespace EmiliosStore.Vistas
{
    partial class Vista04DetalleJuegoForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista04DetalleJuegoForm";
            Text = "V04 - Detalle del juego";
            ResumeLayout(false);
        }
    }
}
