namespace EmiliosStore.Vistas
{
    // V06: carrito y pago.
    public partial class Vista06CarritoForm : Form
    {
        public Vista06CarritoForm()
        {
            InitializeComponent();
        }
    }
}
