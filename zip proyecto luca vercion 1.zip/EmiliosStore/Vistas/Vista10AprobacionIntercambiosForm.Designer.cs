namespace EmiliosStore.Vistas
{
    partial class Vista10AprobacionIntercambiosForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista10AprobacionIntercambiosForm";
            Text = "V10 - Aprobación de intercambios";
            ResumeLayout(false);
        }
    }
}
