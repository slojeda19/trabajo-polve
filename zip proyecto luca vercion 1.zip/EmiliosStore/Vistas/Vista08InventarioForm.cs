namespace EmiliosStore.Vistas
{
    // V08: gestión de inventario.
    public partial class Vista08InventarioForm : Form
    {
        public Vista08InventarioForm()
        {
            InitializeComponent();
        }
    }
}
