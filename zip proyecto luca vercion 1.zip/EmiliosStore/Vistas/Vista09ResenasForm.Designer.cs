namespace EmiliosStore.Vistas
{
    partial class Vista09ResenasForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista09ResenasForm";
            Text = "V09 - Reseñas";
            ResumeLayout(false);
        }
    }
}
