﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EmiliosStore.Vistas
{
    public partial class FormBueno : Form
    {
        public FormBueno()
        {
            InitializeComponent();
        }
    }
}
