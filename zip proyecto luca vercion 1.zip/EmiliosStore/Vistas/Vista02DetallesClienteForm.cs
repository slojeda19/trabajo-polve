namespace EmiliosStore.Vistas
{
    // V02: datos e historial del cliente.
    public partial class Vista02DetallesClienteForm : Form
    {
        public Vista02DetallesClienteForm()
        {
            InitializeComponent();
        }
    }
}
