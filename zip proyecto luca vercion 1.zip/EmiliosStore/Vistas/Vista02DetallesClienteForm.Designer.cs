namespace EmiliosStore.Vistas
{
    partial class Vista02DetallesClienteForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista02DetallesClienteForm";
            Text = "V02 - Detalles del cliente";
            ResumeLayout(false);
        }
    }
}
