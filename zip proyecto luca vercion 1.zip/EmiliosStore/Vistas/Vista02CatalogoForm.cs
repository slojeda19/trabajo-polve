using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Sucursales;

namespace EmiliosStore.Vistas
{
    // V02: catálogo de videojuegos.
    public partial class Vista02CatalogoForm : Form
    {
        public Vista02CatalogoForm()
        {
            InitializeComponent();

            // Carga las sucursales sin cambiar el ComboBox diseñado.
            comboBox1.DataSource = AppData.Sucursales;
            comboBox1.DisplayMember = "Direccion";
            comboBox1.SelectedIndexChanged += (_, _) => CargarJuegos();

            // Estas acciones se usan una sola vez, por eso quedan directamente en el evento.
            button1.Click += (_, _) => new Vista03BuscadorForm().ShowDialog();
            button2.Click += (_, _) =>
            {
                new Vista06CarritoForm().ShowDialog();
                CargarJuegos();
            };
            button3.Click += VerDetalle;
            dataGridView1.CellDoubleClick += (_, _) => VerDetalle(null, EventArgs.Empty);

            dataGridView1.ReadOnly = true;
            dataGridView1.MultiSelect = false;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            CargarJuegos();
        }

        // Muestra en la tabla los juegos de la sucursal seleccionada.
        private void CargarJuegos()
        {
            if (comboBox1.SelectedItem is not Sucursal sucursal) return;

            dataGridView1.DataSource = sucursal.Inventario.Videojuegos
                .Select(juego => new
                {
                    juego.Nombre,
                    Genero = juego.Genero.Nombre,
                    juego.Precio,
                    Puntaje = juego.Resena?.Puntaje ?? 0,
                    juego.Stock
                })
                .ToList();
        }

        // Obtiene la fila seleccionada y muestra sus datos sin alterar el diseño de V02.
        private void VerDetalle(object? sender, EventArgs e)
        {
            if (comboBox1.SelectedItem is not Sucursal sucursal || dataGridView1.CurrentRow == null)
            {
                MessageBox.Show("Seleccioná un juego de la tabla.");
                return;
            }

            string? nombre = dataGridView1.CurrentRow.Cells["Nombre"].Value?.ToString();
            Videojuego? juego = sucursal.Inventario.Videojuegos.FirstOrDefault(j => j.Nombre == nombre);
            if (juego == null) return;

            MessageBox.Show(
                $"{juego.Nombre}\nGénero: {juego.Genero.Nombre}\nPrecio: ${juego.Precio:N0}\n" +
                $"Stock: {juego.Stock}\nRating: {juego.Resena?.Puntaje ?? 0}/10\n\n" +
                $"{juego.Resena?.Descripcion ?? "Sin reseña"}",
                "Detalle del juego"
            );
        }
    }
}
