namespace EmiliosStore.Vistas
{
    partial class Vista08InventarioForm
    {
        private void InitializeComponent()
        {
            SuspendLayout();
            ClientSize = new System.Drawing.Size(800, 450);
            Name = "Vista08InventarioForm";
            Text = "V08 - Inventario";
            ResumeLayout(false);
        }
    }
}
