namespace EmiliosStore.Vistas
{
    // V10: aprobación de intercambios.
    public partial class Vista10AprobacionIntercambiosForm : Form
    {
        public Vista10AprobacionIntercambiosForm()
        {
            InitializeComponent();
        }
    }
}
