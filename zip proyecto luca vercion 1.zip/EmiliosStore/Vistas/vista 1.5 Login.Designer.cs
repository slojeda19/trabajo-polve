﻿namespace EmiliosStore.Vistas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            BTN_CrearCuenta = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(361, 55);
            label1.Margin = new Padding(7, 0, 7, 0);
            label1.Name = "label1";
            label1.Size = new Size(185, 60);
            label1.TabIndex = 0;
            label1.Text = "Registro";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(96, 151);
            label2.Name = "label2";
            label2.Size = new Size(145, 45);
            label2.TabIndex = 1;
            label2.Text = "Nombre:";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(96, 255);
            label3.Name = "label3";
            label3.Size = new Size(160, 45);
            label3.TabIndex = 2;
            label3.Text = "Direccion:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(96, 355);
            label4.Name = "label4";
            label4.Size = new Size(82, 45);
            label4.TabIndex = 3;
            label4.Text = "DNI:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(96, 456);
            label5.Name = "label5";
            label5.Size = new Size(135, 45);
            label5.TabIndex = 4;
            label5.Text = "Usuario:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(96, 562);
            label6.Name = "label6";
            label6.Size = new Size(187, 45);
            label6.TabIndex = 5;
            label6.Text = "Contraseña:";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 9F);
            textBox1.Location = new Point(96, 199);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(786, 31);
            textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 12F);
            textBox2.Location = new Point(96, 303);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(786, 39);
            textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Segoe UI", 12F);
            textBox3.Location = new Point(96, 403);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(786, 39);
            textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Segoe UI", 12F);
            textBox4.Location = new Point(96, 504);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(786, 39);
            textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Segoe UI", 12F);
            textBox5.Location = new Point(96, 610);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(786, 39);
            textBox5.TabIndex = 10;
            // 
            // BTN_CrearCuenta
            // 
            BTN_CrearCuenta.Location = new Point(157, 729);
            BTN_CrearCuenta.Name = "BTN_CrearCuenta";
            BTN_CrearCuenta.Size = new Size(285, 85);
            BTN_CrearCuenta.TabIndex = 11;
            BTN_CrearCuenta.Text = "Crear Cuenta";
            BTN_CrearCuenta.UseVisualStyleBackColor = true;
            BTN_CrearCuenta.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(551, 729);
            button2.Name = "button2";
            button2.Size = new Size(199, 85);
            button2.TabIndex = 12;
            button2.Text = "Volver";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(24F, 60F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(964, 938);
            Controls.Add(button2);
            Controls.Add(BTN_CrearCuenta);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 22F);
            Margin = new Padding(7);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private Button BTN_CrearCuenta;
        private Button button2;
    }
}
