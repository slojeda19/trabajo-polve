namespace EmiliosStore.Vistas
{
    partial class Vista02CatalogoForm
    {
        private void InitializeComponent()
        {
            label1 = new Label();
            comboBox1 = new ComboBox();
            button1 = new Button();
            button2 = new Button();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(485, 55);
            label1.Name = "label1";
            label1.Size = new Size(211, 60);
            label1.TabIndex = 0;
            label1.Text = "Catalogo";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(86, 141);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(330, 33);
            comboBox1.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(838, 141);
            button1.Name = "button1";
            button1.Size = new Size(135, 48);
            button1.TabIndex = 2;
            button1.Text = "Buscador";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(1002, 141);
            button2.Name = "button2";
            button2.Size = new Size(128, 48);
            button2.TabIndex = 3;
            button2.Text = "Carrito";
            button2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(47, 213);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1083, 341);
            dataGridView1.TabIndex = 4;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(419, 580);
            button3.Name = "button3";
            button3.Size = new Size(349, 43);
            button3.TabIndex = 5;
            button3.Text = "Ver detalles del juego";
            button3.UseVisualStyleBackColor = true;
            // 
            // Vista02CatalogoForm
            // 
            ClientSize = new Size(1201, 646);
            Controls.Add(button3);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(label1);
            Name = "Vista02CatalogoForm";
            Text = "V02 - Catálogo";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private ComboBox comboBox1;
        private Button button1;
        private Button button2;
        private DataGridView dataGridView1;
        private Button button3;
    }
}
