namespace EmiliosStore.Vistas
{
    // V04: detalle de un videojuego.
    public partial class Vista04DetalleJuegoForm : Form
    {
        public Vista04DetalleJuegoForm()
        {
            InitializeComponent();
        }
    }
}
