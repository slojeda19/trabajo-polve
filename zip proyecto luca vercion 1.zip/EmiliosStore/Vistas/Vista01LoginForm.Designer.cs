namespace EmiliosStore.Vistas
{
    partial class Vista01LoginForm
    {
        private void InitializeComponent()
        {
            lbl_titulo = new Label();
            lbl_usuario = new Label();
            txt_usuario = new TextBox();
            txt_contraseña = new TextBox();
            lvl_contraseña = new Label();
            btn_ingresar = new Button();
            btn_crearcuenta = new Button();
            label1 = new Label();
            lbl_tipodeusuario = new Label();
            cbx_tipodeusuario = new ComboBox();
            SuspendLayout();
            // 
            // lbl_titulo
            // 
            lbl_titulo.AutoSize = true;
            lbl_titulo.Font = new Font("Snap ITC", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lbl_titulo.Location = new Point(122, 40);
            lbl_titulo.Name = "lbl_titulo";
            lbl_titulo.Size = new Size(404, 63);
            lbl_titulo.TabIndex = 0;
            lbl_titulo.Text = "Emilios Store";
            // 
            // lbl_usuario
            // 
            lbl_usuario.AutoSize = true;
            lbl_usuario.Font = new Font("Segoe UI", 15F);
            lbl_usuario.Location = new Point(28, 133);
            lbl_usuario.Name = "lbl_usuario";
            lbl_usuario.Size = new Size(126, 41);
            lbl_usuario.TabIndex = 1;
            lbl_usuario.Text = "Usuario:";
            lbl_usuario.Click += label2_Click;
            // 
            // txt_usuario
            // 
            txt_usuario.Location = new Point(28, 177);
            txt_usuario.Name = "txt_usuario";
            txt_usuario.Size = new Size(618, 31);
            txt_usuario.TabIndex = 2;
            // 
            // txt_contraseña
            // 
            txt_contraseña.Location = new Point(28, 274);
            txt_contraseña.Name = "txt_contraseña";
            txt_contraseña.Size = new Size(618, 31);
            txt_contraseña.TabIndex = 3;
            // 
            // lvl_contraseña
            // 
            lvl_contraseña.AutoSize = true;
            lvl_contraseña.Font = new Font("Segoe UI", 15F);
            lvl_contraseña.Location = new Point(28, 239);
            lvl_contraseña.Name = "lvl_contraseña";
            lvl_contraseña.Size = new Size(175, 41);
            lvl_contraseña.TabIndex = 4;
            lvl_contraseña.Text = "Contraseña:";
            // 
            // btn_ingresar
            // 
            btn_ingresar.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_ingresar.Location = new Point(28, 447);
            btn_ingresar.Name = "btn_ingresar";
            btn_ingresar.Size = new Size(618, 51);
            btn_ingresar.TabIndex = 5;
            btn_ingresar.Text = "ingresar";
            btn_ingresar.UseVisualStyleBackColor = true;
            btn_ingresar.Click += button1_Click;
            // 
            // btn_crearcuenta
            // 
            btn_crearcuenta.Font = new Font("Segoe UI", 12F);
            btn_crearcuenta.Location = new Point(28, 504);
            btn_crearcuenta.Name = "btn_crearcuenta";
            btn_crearcuenta.Size = new Size(618, 51);
            btn_crearcuenta.TabIndex = 6;
            btn_crearcuenta.Text = "Crear Cuenta";
            btn_crearcuenta.UseVisualStyleBackColor = true;
            btn_crearcuenta.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(1069, 375);
            label1.Name = "label1";
            label1.Size = new Size(0, 25);
            label1.TabIndex = 7;
            // 
            // lbl_tipodeusuario
            // 
            lbl_tipodeusuario.AutoSize = true;
            lbl_tipodeusuario.Font = new Font("Segoe UI", 15F);
            lbl_tipodeusuario.Location = new Point(28, 326);
            lbl_tipodeusuario.Name = "lbl_tipodeusuario";
            lbl_tipodeusuario.Size = new Size(218, 41);
            lbl_tipodeusuario.TabIndex = 8;
            lbl_tipodeusuario.Text = "tipo de usuario";
            // 
            // cbx_tipodeusuario
            // 
            cbx_tipodeusuario.FormattingEnabled = true;
            cbx_tipodeusuario.Location = new Point(28, 370);
            cbx_tipodeusuario.Name = "cbx_tipodeusuario";
            cbx_tipodeusuario.Size = new Size(618, 33);
            cbx_tipodeusuario.TabIndex = 9;
            // 
            // Vista01LoginForm
            // 
            ClientSize = new Size(693, 598);
            Controls.Add(cbx_tipodeusuario);
            Controls.Add(lbl_tipodeusuario);
            Controls.Add(label1);
            Controls.Add(btn_crearcuenta);
            Controls.Add(btn_ingresar);
            Controls.Add(lvl_contraseña);
            Controls.Add(txt_contraseña);
            Controls.Add(txt_usuario);
            Controls.Add(lbl_usuario);
            Controls.Add(lbl_titulo);
            Name = "Vista01LoginForm";
            Text = "V01 - Login";
            ResumeLayout(false);
            PerformLayout();
        }

        private Label lbl_titulo;
        private Label lbl_usuario;
        private TextBox txt_usuario;
        private TextBox txt_contraseña;
        private Label lvl_contraseña;
        private Button btn_ingresar;
        private Button btn_crearcuenta;
        private Label label1;
        private Label lbl_tipodeusuario;
        private ComboBox cbx_tipodeusuario;
    }
}
