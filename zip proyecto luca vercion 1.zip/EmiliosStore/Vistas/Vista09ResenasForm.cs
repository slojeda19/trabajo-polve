namespace EmiliosStore.Vistas
{
    // V09: edición de reseñas.
    public partial class Vista09ResenasForm : Form
    {
        public Vista09ResenasForm()
        {
            InitializeComponent();
        }
    }
}
