using EmiliosStore.Modelos.Catalogo;
using EmiliosStore.Modelos.Operaciones;
using EmiliosStore.Modelos.Personas;
using EmiliosStore.Modelos.Sucursales;

namespace EmiliosStore.Vistas
{
    // Simula la base de datos durante la demostración escolar.
    // "static" permite que todas las vistas compartan los mismos datos.
    internal static class AppData
    {
        // "readonly" evita reemplazar estas listas durante la ejecución.
        // Las dos sucursales tienen inventarios independientes.
        public static readonly Sucursal SucursalSan = new("San");
        public static readonly Sucursal SucursalJudas = new("Judas");
        public static readonly List<Sucursal> Sucursales = new() { SucursalSan, SucursalJudas };
        public static readonly List<Cliente> Clientes = new();
        public static readonly List<Intercambio> Intercambios = new();
        public static readonly List<ItemCarrito> Carrito = new();
        // El signo ? permite que no haya cliente conectado todavía.
        public static Cliente? ClienteActual;

        // Guarda el rol que inició sesión para aplicar permisos en las vistas del personal.
        public static string RolActual = "";

        static AppData()
        {
            // Carga información inicial para poder probar la aplicación.
            Genero terror = new("Terror");
            Genero deportes = new("Deportes");
            Genero aventura = new("Aventura");
            AgregarJuego(SucursalSan, "Resident Evil 4", terror, 45000, 4, "Una aventura de terror excelente.", 9);
            AgregarJuego(SucursalSan, "EA Sports FC", deportes, 38000, 7, "Ideal para jugar con amigos.", 8);
            AgregarJuego(SucursalSan, "Zelda: Tears of the Kingdom", aventura, 60000, 3, "Una aventura enorme y creativa.", 10);
            AgregarJuego(SucursalJudas, "Resident Evil 4", terror, 45000, 2, "Una aventura de terror excelente.", 9);
            AgregarJuego(SucursalJudas, "EA Sports FC", deportes, 38000, 5, "Ideal para jugar con amigos.", 8);
            AgregarJuego(SucursalJudas, "Zelda: Tears of the Kingdom", aventura, 60000, 1, "Una aventura enorme y creativa.", 10);
            Clientes.Add(new Cliente("Cliente Demo", "00000000", "Calle 1", "cliente", "1234"));
        }

        // Une los inventarios para las vistas que necesitan ver todas las sucursales.
        public static List<Videojuego> TodosLosJuegos => Sucursales.SelectMany(s => s.Inventario.Videojuegos).ToList();

        public static void AgregarJuego(Sucursal sucursal, string nombre, Genero genero, decimal precio, int stock, string resena, int puntaje)
        {
            // Crea el juego, su reseña y lo incorpora al inventario.
            // Si ya existe en otra sucursal, conserva la misma reseña de Emilio.
            Videojuego? juegoExistente = TodosLosJuegos.FirstOrDefault(j => string.Equals(j.Nombre, nombre, StringComparison.OrdinalIgnoreCase));
            Videojuego juego = new(nombre, genero, precio, stock);
            string descripcion = juegoExistente?.Resena?.Descripcion ?? resena;
            int puntajeFinal = juegoExistente?.Resena?.Puntaje ?? puntaje;
            juego.Resena = new Reseña(juego, descripcion, puntajeFinal);
            genero.AgregarVideojuego(juego);
            sucursal.Inventario.AgregarVideojuego(juego);
        }

        // Elimina un juego de la sucursal elegida y de listas donde aún estaba reservado.
        public static void EliminarJuego(Sucursal sucursal, Videojuego juego)
        {
            sucursal.Inventario.Videojuegos.Remove(juego);
            juego.Genero.Videojuegos.Remove(juego);
            Carrito.RemoveAll(item => ReferenceEquals(item.Juego, juego));
            Intercambios.RemoveAll(intercambio => ReferenceEquals(intercambio.JuegoSolicitado, juego));
        }
    }
}
