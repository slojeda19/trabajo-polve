﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EmiliosStore.Modelos.Personas;

namespace EmiliosStore.Vistas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // El texto de contraseña se muestra con puntos para protegerlo visualmente.
            textBox5.UseSystemPasswordChar = true;
        }

        // Cierra Registro y devuelve al usuario al Login.
        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
               string.IsNullOrWhiteSpace(textBox2.Text) ||
               string.IsNullOrWhiteSpace(textBox3.Text) ||
               string.IsNullOrWhiteSpace(textBox4.Text) ||
               string.IsNullOrWhiteSpace(textBox5.Text))
            {
                MessageBox.Show("Completá todos los campos.");
                return;
            }

            foreach (Cliente cliente in AppData.Clientes)
            {
                if (cliente.Usuario == textBox4.Text.Trim())
                {
                    MessageBox.Show("Ese usuario ya existe.");
                    return;
                }
            }

            Cliente nuevoCliente = new Cliente(
                textBox1.Text.Trim(),
                textBox3.Text.Trim(),
                textBox2.Text.Trim(),
                textBox4.Text.Trim(),
                textBox5.Text
            );

            AppData.Clientes.Add(nuevoCliente);
            MessageBox.Show("Cuenta creada correctamente. Ya podés iniciar sesión.");
            Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
