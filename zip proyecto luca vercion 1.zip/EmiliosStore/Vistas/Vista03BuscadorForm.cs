namespace EmiliosStore.Vistas
{
    // V03: buscador de videojuegos.
    public partial class Vista03BuscadorForm : Form
    {
        public Vista03BuscadorForm()
        {
            InitializeComponent();
        }
    }
}
